package com.example.firstflutterproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
